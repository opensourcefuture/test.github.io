Event.onLoad = 
    function (bot)

        print("载入bot",bot:getId(),"成功")

        bot:subscribeGroupMsg(
            function(bot, msg, group, sender)

                if tostring(msg):find("夸我") then
                    group:sendMsg( net.get("https://chp.shadiao.app/api.php"))
                end

                if tostring(msg):find("骂我") then
                    group:sendMsg(net.get("https://nmsl.shadiao.app/api.php?level=min&lang=zh_cn"))
                end

                if tostring(msg):find("复读") then
                    group:sendMsg(msg)
                end
                

            end
        )
    end


Event.onFinish = 
    function ()
        print("脚本被卸载！")
    end